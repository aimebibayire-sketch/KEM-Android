package com.kem.assistant

import org.json.JSONObject

data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val title: String,
    val english: String,
    val daily: Boolean,
    val enabled: Boolean = true
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("hour", hour); put("minute", minute)
        put("title", title); put("english", english)
        put("daily", daily); put("enabled", enabled)
    }
    companion object {
        fun fromJson(o: JSONObject) = AlarmItem(
            o.getInt("id"), o.getInt("hour"), o.getInt("minute"),
            o.getString("title"), o.optString("english", ""),
            o.optBoolean("daily", false), o.optBoolean("enabled", true)
        )
    }
}
