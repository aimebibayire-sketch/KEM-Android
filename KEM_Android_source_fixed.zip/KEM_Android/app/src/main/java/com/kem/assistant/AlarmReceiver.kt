package com.kem.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 1)
        val title = intent.getStringExtra("title") ?: "Activité programmée"
        val english = intent.getStringExtra("english") ?: ""
        val daily = intent.getBooleanExtra("daily", false)
        val hour = intent.getIntExtra("hour", 8)
        val minute = intent.getIntExtra("minute", 0)

        val channelId = "kem_alarms"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(channelId) == null) {
            val channel = NotificationChannel(channelId, "Alarmes KEM", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "Rappels et alarmes de KEM"
            channel.enableVibration(true)
            channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
            nm.createNotificationChannel(channel)
        }

        val screen = Intent(context, AlarmScreenActivity::class.java).apply {
            putExtra("title", title); putExtra("english", english)
            putExtra("id", id); putExtra("daily", daily)
            putExtra("hour", hour); putExtra("minute", minute)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val fullScreen = PendingIntent.getActivity(
            context, id, screen, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("KEM — C'est l'heure !")
            .setContentText(title)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setFullScreenIntent(fullScreen, true)
            .setContentIntent(fullScreen)
            .build()
        nm.notify(id, notification)

        if (daily) {
            AlarmScheduler.schedule(context, AlarmItem(id, hour, minute, title, english, true, true))
        } else {
            val updated = AlarmStore.all(context).filterNot { it.id == id }
            AlarmStore.save(context, updated)
        }
    }
}
