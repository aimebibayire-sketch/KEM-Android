package com.kem.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val blue = 0xFF65A5FF.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB9C9E3.toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        buildUi()
    }
    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF0B1426.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = TextView(this).apply {
            text = "KEM"; textSize = 34f; setTextColor(blue); gravity = Gravity.CENTER_VERTICAL
        }
        val sub = TextView(this).apply {
            text = "TON ASSISTANT PERSONNEL\nYour personal time assistant"
            textSize = 14f; setTextColor(muted); setPadding(0, 4, 0, 22)
        }
        val now = TextView(this).apply {
            text = SimpleDateFormat("EEEE dd MMMM • HH:mm", Locale.FRENCH).format(Date())
            textSize = 15f; setTextColor(white); setPadding(0, 4, 0, 18)
        }
        val add = Button(this).apply {
            text = "+  AJOUTER UN RAPPEL"
            setOnClickListener { addAlarm() }
        }
        val section = TextView(this).apply {
            text = "MES PROCHAINS RAPPELS"; textSize = 16f; setTextColor(blue)
            setPadding(0, 28, 0, 12)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(top); content.addView(sub); content.addView(now)
        content.addView(add); content.addView(section); content.addView(list)
        scroll.addView(content); root.addView(scroll)
        setContentView(root)
        renderAlarms()
    }
    private fun addAlarm() {
        val input = EditText(this).apply { hint = "Activité (ex. : Leçon d'anglais)" }
        val english = EditText(this).apply { hint = "English announcement (optional)" }
        val daily = CheckBox(this).apply { text = "Répéter tous les jours"; setTextColor(white) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0)
            addView(input); addView(english); addView(daily)
        }
        AlertDialog.Builder(this).setTitle("Nouvelle activité")
            .setView(box)
            .setPositiveButton("Choisir l'heure") { _, _ ->
                val title = input.text.toString().trim()
                if (title.isBlank()) { Toast.makeText(this, "Saisis une activité", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val cal = java.util.Calendar.getInstance()
                TimePickerDialog(this, { _, h, m ->
                    val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
                    val item = AlarmItem(id, h, m, title, english.text.toString().trim(), daily.isChecked)
                    val items = AlarmStore.all(this); items.add(item); AlarmStore.save(this, items)
                    AlarmScheduler.schedule(this, item)
                    renderAlarms()
                    Toast.makeText(this, "Rappel KEM enregistré", Toast.LENGTH_SHORT).show()
                }, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE), true).show()
            }.setNegativeButton("Annuler", null).show()
    }
    private fun renderAlarms() {
        list.removeAllViews()
        val items = AlarmStore.all(this).sortedWith(compareBy<AlarmItem> { it.hour }.thenBy { it.minute })
        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Aucun rappel pour le moment.\nAjoute ta première activité !"
                setTextColor(muted); textSize = 15f; setPadding(0, 12, 0, 20)
            }
            list.addView(empty)
        }
        items.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16)
                setBackgroundColor(0xFF172641.toInt())
            }
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val time = TextView(this).apply {
                text = String.format("%02d:%02d", item.hour, item.minute)
                textSize = 25f; setTextColor(blue); setPadding(0, 0, 16, 0)
            }
            val name = TextView(this).apply {
                text = item.title + if (item.daily) "\nTous les jours" else "\nUne seule fois"
                textSize = 15f; setTextColor(white)
            }
            val delete = Button(this).apply {
                text = "×"; setOnClickListener {
                    AlarmScheduler.cancel(this@MainActivity, item)
                    val updated = AlarmStore.all(this@MainActivity).filterNot { it.id == item.id }
                    AlarmStore.save(this@MainActivity, updated); renderAlarms()
                }
            }
            line.addView(time); line.addView(name, LinearLayout.LayoutParams(0, -2, 1f)); line.addView(delete)
            card.addView(line)
            val params = LinearLayout.LayoutParams(-1, -2); params.bottomMargin = 12
            list.addView(card, params)
        }
    }
}
