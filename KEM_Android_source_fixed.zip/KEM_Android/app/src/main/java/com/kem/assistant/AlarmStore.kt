package com.kem.assistant

import android.content.Context
import org.json.JSONArray

object AlarmStore {
    private const val PREFS = "kem_local"
    private const val KEY = "alarms"

    fun all(context: Context): MutableList<AlarmItem> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i -> AlarmItem.fromJson(arr.getJSONObject(i)) }
    }

    fun save(context: Context, items: List<AlarmItem>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }
}
