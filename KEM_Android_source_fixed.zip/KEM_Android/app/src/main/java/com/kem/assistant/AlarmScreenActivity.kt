package com.kem.assistant

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class AlarmScreenActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speech = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val title = intent.getStringExtra("title") ?: "C'est l'heure !"
        val english = intent.getStringExtra("english") ?: ""
        speech = if (english.isNotBlank()) "$title. $english" else title

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
            setBackgroundColor(0xFF0B1426.toInt())
        }
        val brand = TextView(this).apply {
            text = "KEM"; textSize = 34f; setTextColor(0xFF65A5FF.toInt())
            gravity = Gravity.CENTER
        }
        val heading = TextView(this).apply {
            text = "C'EST L'HEURE !"; textSize = 17f
            setTextColor(0xFFB9C9E3.toInt()); gravity = Gravity.CENTER
            setPadding(0, 28, 0, 12)
        }
        val task = TextView(this).apply {
            text = title; textSize = 28f; setTextColor(-1)
            gravity = Gravity.CENTER; setPadding(0, 8, 0, 24)
        }
        val done = Button(this).apply {
            text = "TERMINÉ"; setOnClickListener { stopSpeaking(); finish() }
        }
        val repeat = Button(this).apply {
            text = "RÉPÉTER DANS 10 MIN"; setOnClickListener {
                val id = intent.getIntExtra("id", 1)
                val item = AlarmItem(id, java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY),
                    java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE) + 10,
                    title, english, false, true)
                val safeMinute = item.minute % 60
                val safeHour = (item.hour + item.minute / 60) % 24
                AlarmScheduler.schedule(this@AlarmScreenActivity,
                    item.copy(hour = safeHour, minute = safeMinute))
                stopSpeaking(); finish()
            }
        }
        root.addView(brand); root.addView(heading); root.addView(task)
        root.addView(done); root.addView(repeat)
        setContentView(root)
        tts = TextToSpeech(this, this)
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.FRENCH
            tts?.setSpeechRate(1.08f)
            tts?.speak(speech, TextToSpeech.QUEUE_FLUSH, null, "KEM_ALARM")
        }
    }
    private fun stopSpeaking() { tts?.stop() }
    override fun onDestroy() { stopSpeaking(); tts?.shutdown(); super.onDestroy() }
}
