# KEM — Assistant personnel Android (prototype natif)

Ce projet est le premier socle Android natif de KEM : rappels locaux, alarmes,
annonces vocales via le moteur Text-to-Speech du téléphone et restauration des
alarmes après redémarrage.

## Ouvrir le projet
1. Installer Android Studio sur un ordinateur.
2. Ouvrir le dossier `KEM_Android` dans Android Studio.
3. Laisser Gradle synchroniser les dépendances (une connexion Internet est
   nécessaire pour cette étape de compilation).
4. Connecter un téléphone Android avec le débogage USB activé, puis cliquer Run.
5. Sur le téléphone, autoriser les notifications et, si Android le demande,
   les alarmes exactes / affichages plein écran.

## Utilisation
- Appuyer sur « AJOUTER UN RAPPEL ».
- Saisir le titre en français et, facultativement, une annonce en anglais.
- Choisir l'heure et la répétition quotidienne.
- À l'heure prévue, KEM affiche une notification d'alarme et tente d'ouvrir
  l'écran de rappel avec annonce vocale.
- Les données sont conservées localement sur le téléphone.

## Limites de cette première version
- C'est un projet source Android, pas encore un APK signé prêt à installer.
- La voix utilise les langues installées dans le moteur vocal Android. Le
  téléchargement préalable des voix françaises/anglaises peut être nécessaire.
- Android et certains fabricants peuvent limiter les alarmes selon les réglages
  d'économie de batterie. Accorder les autorisations demandées et autoriser
  KEM en arrière-plan.
- La répétition est quotidienne ou ponctuelle dans ce premier prototype.
- Le choix automatique de langue selon le texte, les jours de semaine,
  l'historique, le mode snooze fiable et les réglages détaillés sont prévus
  pour les versions suivantes.
- Sur Android récent, les alarmes exactes et les notifications plein écran
  dépendent des autorisations système et des règles de la version Android.

## Identité visuelle
Mode sombre bleu nuit, accents bleus, assistant bilingue français/anglais,
style vocal dynamique.
